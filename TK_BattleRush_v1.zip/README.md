# TK BattleRush v1

Native Android starter for TK BattleRush.

Included:
- Home
- Full Map Kill
- Full Map Survival
- CS 4v4
- CS Headshot
- Lone Wolf 1v1
- Lone Wolf 2v2
- Lone Wolf Lose to Win
- Matches
- Wallet
- Profile

This version is the first working UI foundation. Real authentication, server-side tournaments, payments, result verification and withdrawals are not connected yet.
