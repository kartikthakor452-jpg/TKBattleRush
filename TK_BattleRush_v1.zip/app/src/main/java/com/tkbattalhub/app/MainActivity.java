package com.tkbattlerush.app;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private TextView content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        content = findViewById(R.id.content);
        findViewById(R.id.navHome).setOnClickListener(v -> show("HOME"));
        findViewById(R.id.navMatches).setOnClickListener(v -> show("MATCHES"));
        findViewById(R.id.navWallet).setOnClickListener(v -> show("WALLET"));
        findViewById(R.id.navProfile).setOnClickListener(v -> show("PROFILE"));
        show("HOME");
    }

    private void show(String page) {
        if (page.equals("HOME")) {
            content.setText("UPCOMING TOURNAMENTS\n\n" +
                    "🪂 FULL MAP • KILL\n" +
                    "₹10 per kill  •  8:30 PM\n\n" +
                    "🏆 FULL MAP • SURVIVAL\n" +
                    "Top 10 rewards  •  9:30 PM\n\n" +
                    "💥 CS 4v4\n" +
                    "Today • 10:00 PM\n\n" +
                    "🎯 CS HEADSHOT\n" +
                    "Today • 10:30 PM\n\n" +
                    "🐺 LONE WOLF 1v1\n" +
                    "Today • 11:00 PM\n\n" +
                    "🐺 LONE WOLF 2v2\n" +
                    "Today • 11:30 PM\n\n" +
                    "💰 LOSE TO WIN\n" +
                    "Today • 12:00 AM");
        } else if (page.equals("MATCHES")) {
            content.setText("MY MATCHES\n\nNo joined matches yet.\n\nJoin a tournament from Home.");
        } else if (page.equals("WALLET")) {
            content.setText("WALLET\n\nDeposit Balance   ₹0\nWinning Balance   ₹0\n\nTransaction History\nNo transactions yet.");
        } else {
            content.setText("PROFILE\n\nTK BattleRush Player\n\nUID: Not verified\nAccount status: Active");
        }
    }
}
